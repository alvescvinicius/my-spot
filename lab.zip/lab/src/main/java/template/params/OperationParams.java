package template.params;

public class OperationParams {
	
	// --
	// -- Parametros de operacao
	// -- 
	public static String COIN_BASE = "USDT";
	public static String COIN_TRADE = "BTC";
	public static String COIN_SYMBOL = COIN_TRADE + COIN_BASE;
	public static String INTERVAL = "1h";
	public static int LIMIT = 100;
	
	// --
	// -- Parametros de EMA macro
	// --
	public static String EMA_MACRO_DESCRIPTION = "MACRO";
	public static String EMA_MACRO_INTERVAL = "1h";
	public static int EMA_MACRO_LIMIT = 50;
	public static int EMA_MACRO_SHORT_PERIOD = 9;
	public static int EMA_MACRO_MEDIUM_PERIOD = 21;
	public static int EMA_MACRO_LONG_PERIOD = 48;
	
	// --
	// -- Parametros de EMA micro
	// -- 
	public static String EMA_MICRO_DESCRIPTION = "MICRO";
	public static String EMA_MICRO_INTERVAL = "5m";
	public static int EMA_MICRO_LIMIT = 50;
	public static int EMA_MICRO_SHORT_PERIOD = 9;
	public static int EMA_MICRO_MEDIUM_PERIOD = 21;
	public static int EMA_MICRO_LONG_PERIOD = 48;
	
	// --
	// -- Parametros de Compra
	// --
	
	
	// --
	// -- Parametros de Venda
	// --
	
}
