package template.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import template.model.Ema;

@Repository
public interface EmaRepository extends JpaRepository<Ema, Long> {

	@Query(value = "SELECT * FROM ema e WHERE e.id_operation = :idOperation AND e.description = :description ORDER BY e.date_criation DESC LIMIT 1", nativeQuery = true)
	Ema getLastEmaMacro(@Param("idOperation") Long idOperation, @Param("description") String description);

}
