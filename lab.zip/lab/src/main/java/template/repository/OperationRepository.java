package template.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import template.model.Operation;

@Repository
public interface OperationRepository extends JpaRepository<Operation, Long> {
	
	@Query(value = "SELECT * FROM operation o WHERE o.coin_base = :coinBase AND o.coin_trade = :coinTrade ORDER BY o.date_criation DESC LIMIT 1", nativeQuery = true)
	Operation getLastOperation(
            @Param("coinBase") String coinBase,
            @Param("coinTrade") String coinTrade
    );

}
