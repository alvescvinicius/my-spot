package template.dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import template.model.Operation;
import template.params.OperationParams;
import template.repository.OperationRepository;
import template.util.Time;

@Component
public class OperationDao {

	@Autowired
	private OperationRepository operationRepository;

	public Operation getLastOrNewOperation() {

		try {

			Operation operation = new Operation();

			operation = this.operationRepository.getLastOperation(OperationParams.COIN_BASE,
																  OperationParams.COIN_TRADE);

			if (operation == null || new Time().expired(operation.getDateCriation(), 1)) {
				
				Operation oper = new Operation();
				oper.setCoinBase(OperationParams.COIN_BASE);
				oper.setCoinTrade(OperationParams.COIN_TRADE);
				oper.setDateCriation(new Date());
				
				this.operationRepository.save(oper);
				
				return this.operationRepository.getLastOperation(OperationParams.COIN_BASE,
																 OperationParams.COIN_TRADE);
			}

			return operation;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

}
