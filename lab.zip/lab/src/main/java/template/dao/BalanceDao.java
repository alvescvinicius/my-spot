package template.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import template.repository.BalanceRepository;

@Component
public class BalanceDao {

	@Autowired
	private BalanceRepository BalanceRepository;

}
