package template.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import template.model.Ema;
import template.repository.EmaRepository;

@Component
public class EmaDao {

	@Autowired
	private EmaRepository emaRepository;

	public Ema getLastOrNewEmaMacro() {

		try {

			//this.getLastOrNewOperation();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

}
