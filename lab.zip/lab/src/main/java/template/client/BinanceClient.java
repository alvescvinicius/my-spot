package template.client;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import template.dto.Account;
import template.dto.Kline;
import template.dto.Ticker;
import template.util.BinanceServerVO;
import template.util.Request;

@Component
public class BinanceClient {

	private static final String API_KEY = System.getenv("BINANCE_API_KEY");
	private static final String API_SECRET = System.getenv("BINANCE_API_SECRET");

	HashMap<String, String> parameters = new HashMap<String, String>();
	Request httpRequest;

	public BinanceClient() {
		String baseUrl = "https://api.binance.com";
		httpRequest = new Request(baseUrl, API_KEY, API_SECRET);
	}

	public BinanceClient(String baseUrl) {
		httpRequest = new Request(baseUrl, API_KEY, API_SECRET);
	}

	public long getBinanceServerTime() throws IOException {
		String url = "https://api.binance.com/api/v3/time";
		RestTemplate restTemplate = new RestTemplate();
		BinanceServerVO binance = restTemplate.getForObject(url, BinanceServerVO.class);
		return binance.getServerTime();
	}

	public List<Kline> getKlineInformations(String symbol, String interval, int limit) throws Exception {
		try {
			parameters.put("symbol", symbol);
			parameters.put("interval", interval);
			parameters.put("limit", String.valueOf(limit));
			String response = httpRequest.sendPublicRequest(parameters, "/api/v3/klines");
			ObjectMapper mapper = new ObjectMapper();
			List<Kline> klines = mapper.readValue(response, new TypeReference<List<Kline>>() {
			});
			parameters.clear();
			return klines;
		} catch (Exception e) {
			throw e;
		}
	}

	public Ticker getTicketInformations(String symbol) throws Exception {
		parameters.put("symbol", symbol);
		Ticker ticker = new Gson().fromJson(httpRequest.sendPublicRequest(parameters, "/api/v3/ticker/24hr"),
				Ticker.class);
		parameters.clear();
		return ticker;
	}

	/*
	 * public boolean newOrder(String symbol, String side, String quantity, String
	 * price) {
	 * 
	 * try {
	 * 
	 * Double p = (Double.parseDouble(price)); Double q =
	 * (Double.parseDouble(quantity));
	 * 
	 * NumberFormat formatter = new DecimalFormat("#0.00");
	 * 
	 * String priceF = formatter.format(p).replaceAll(",", ".");
	 * 
	 * String qtdF = formatter.format(q).replaceAll(",", ".");
	 * 
	 * parameters.put("symbol", symbol); parameters.put("side", side);
	 * parameters.put("type", "LIMIT"); parameters.put("newClientOrderId", "auto1");
	 * parameters.put("quantity", qtdF); parameters.put("price", priceF);
	 * parameters.put("newOrderRespType", "RESULT"); parameters.put("timeInForce",
	 * "GTC");
	 * 
	 * String response = httpRequest.sendSignedRequest(parameters, "/api/v3/order",
	 * "POST"); parameters.clear();
	 * 
	 * return true;
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * return false; }
	 * 
	 * public Account getAccountInformations() throws Exception { try { Account
	 * account = new Gson().fromJson(httpRequest.sendSignedRequest(parameters,
	 * "/api/v3/account", "GET"), Account.class); return account;
	 * 
	 * } catch (Exception e) { throw e; } }
	 * 
	 * public Balance getBalanceInformations(String asset) throws Exception {
	 * 
	 * List<Balance> balances = this.getAccountInformations().getBalances();
	 * 
	 * for (Balance balance : balances) { if
	 * (balance.getAsset().equalsIgnoreCase(asset)) { return balance; } }
	 * 
	 * return null;
	 * 
	 * }
	 * 
	 */

	/*
	public Account getAccountInformations() throws Exception {
		try {
			Account account = new Gson().fromJson(httpRequest.sendSignedRequest(parameters, "/api/v3/account", "GET"),
					Account.class);
			return account;

		} catch (Exception e) {
			throw e;
		}
	}
	*/

	/*
	public Balance getBalanceInformations(String asset) throws Exception {

		List<Balance> balances = this.getAccountInformations().getBalances();

		for (Balance balance : balances) {
			if (balance.getAsset().equalsIgnoreCase(asset)) {
				return balance;
			}
		}

		return null;

	}
	*/
	
	public Account getAccountInformations() throws Exception  {
		Account account = new Gson().fromJson(httpRequest.sendSignedRequest(parameters, "/api/v3/account", "GET"), Account.class);
		return account;
	}
}