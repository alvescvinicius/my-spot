package template.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "balance")
public class Balance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String asset;
	
	private Double free;
	
	private Double locked;

	public Balance() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAsset() {
		return asset;
	}

	public void setAsset(String asset) {
		this.asset = asset;
	}

	public Double getFree() {
		return free;
	}

	public void setFree(Double free) {
		this.free = free;
	}

	public Double getLocked() {
		return locked;
	}

	public void setLocked(Double locked) {
		this.locked = locked;
	}

	@Override
	public String toString() {
		return "Balance [id=" + id + ", asset=" + asset + ", free=" + free + ", locked=" + locked + "]";
	}

}
