package template.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ema")
public class Ema {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Long idOperation;

	private String description;

	@Column(name = "time_interval")
	private String interval;

	private Double emaShort;

	private Double emaMedium;

	private Double emaLong;

	private Date dateCriation;

	public Ema() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdOperation() {
		return idOperation;
	}

	public void setIdOperation(Long idOperation) {
		this.idOperation = idOperation;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getInterval() {
		return interval;
	}

	public void setInterval(String interval) {
		this.interval = interval;
	}

	public Double getEmaShort() {
		return emaShort;
	}

	public void setEmaShort(Double emaShort) {
		this.emaShort = emaShort;
	}

	public Double getEmaMedium() {
		return emaMedium;
	}

	public void setEmaMedium(Double emaMedium) {
		this.emaMedium = emaMedium;
	}

	public Double getEmaLong() {
		return emaLong;
	}

	public void setEmaLong(Double emaLong) {
		this.emaLong = emaLong;
	}

	public Date getDateCriation() {
		return dateCriation;
	}

	public void setDateCriation(Date dateCriation) {
		this.dateCriation = dateCriation;
	}

}
