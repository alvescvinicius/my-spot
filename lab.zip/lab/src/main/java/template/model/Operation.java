package template.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "operation")
public class Operation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String coinBase;
	
	private String coinTrade;
	
	private Date dateCriation;

	public Operation() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCoinBase() {
		return coinBase;
	}

	public void setCoinBase(String coinBase) {
		this.coinBase = coinBase;
	}

	public String getCoinTrade() {
		return coinTrade;
	}

	public void setCoinTrade(String coinTrade) {
		this.coinTrade = coinTrade;
	}

	public Date getDateCriation() {
		return dateCriation;
	}

	public void setDateCriation(Date dateCriation) {
		this.dateCriation = dateCriation;
	}

	@Override
	public String toString() {
		return "Operation [id=" + id + ", coinBase=" + coinBase + ", coinTrade=" + coinTrade + ", dateCriation="
				+ dateCriation + "]";
	}

}
