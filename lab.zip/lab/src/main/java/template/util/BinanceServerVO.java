package template.util;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BinanceServerVO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("serverTime")
	private long serverTime;

	public long getServerTime() {
		return serverTime;
	}

	public void setServerTime(long serverTime) {
		this.serverTime = serverTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (serverTime ^ (serverTime >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BinanceServerVO other = (BinanceServerVO) obj;
		if (serverTime != other.serverTime)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BinanceServerVO {serverTime=" + serverTime + "}";
	}

}