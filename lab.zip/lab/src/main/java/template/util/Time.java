package template.util;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Time {

	public Logger log = LoggerFactory.getLogger(this.getClass());

	public void wait(int seconds) {
		try {
			TimeUnit.SECONDS.sleep(seconds);
		} catch (Exception e) {
			log.error("TimeUnit.SECONDS.sleep - " + e.getCause());
			e.printStackTrace();
		}
	}
	
	public boolean expired(Date date, int intervalInHour) {
		boolean retorno = false;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.HOUR_OF_DAY, intervalInHour); // add hour
		Date dataExpiracao = cal.getTime();
		Date dataAtual = new Date();
		if (dataExpiracao.before(dataAtual)) {
			retorno = true;
		}
		return retorno;
	}

}
