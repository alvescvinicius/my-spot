package template.util;

import java.util.ArrayList;
import java.util.List;

public class EmaCalculator {
	/**
	 * Calcula a EMA de uma lista de preços
	 *
	 * @param prices Lista de preços (Close)
	 * @param period Período da EMA (ex: 10, 20, 50)
	 * @return Lista com os valores da EMA
	 */
	public static List<Double> calculateEMA(List<Double> prices, int period) {
		List<Double> emaValues = new ArrayList<>();

		if (prices == null || prices.size() < period) {
			return emaValues; // não há dados suficientes
		}

		// Fator de suavização
		double k = 2.0 / (period + 1);

		// Primeiro valor da EMA = SMA (média simples dos primeiros "period" valores)
		double sma = 0.0;
		for (int i = 0; i < period; i++) {
			sma += prices.get(i);
		}
		sma = sma / period;
		emaValues.add(sma);

		// Calcula a EMA sequencial
		double previousEma = sma;
		for (int i = period; i < prices.size(); i++) {
			double price = prices.get(i);
			double ema = (price * k) + (previousEma * (1 - k));
			emaValues.add(ema);
			previousEma = ema;
		}

		return emaValues;
	}
	
	public static Double getLastValue(List<Double> list) {
		return list.isEmpty() ? null : list.get(list.size() - 1);
	}

}
