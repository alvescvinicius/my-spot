package template.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.tomcat.util.json.ParseException;
import org.springframework.web.client.RestTemplate;

public class Request {

	String baseUrl;
	String apiKey;
	String apiSecret;
	Signature sign = new Signature();

	public Request(String baseUrl, String apiKey, String apiSecret) {
		this.baseUrl = baseUrl;
		this.apiKey = apiKey;
		this.apiSecret = apiSecret;
	}

	private String printResponse(HttpURLConnection con) throws IOException, ParseException {
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			//String temp = inputLine.replace("[{", "{");
			//temp = temp.replace("}]", "}");
			//response.append(temp.trim());
			response.append(inputLine);
		}

		in.close();
		return response.toString();
	}

	private void printError(HttpURLConnection con) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getErrorStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		System.out.println(response.toString());
	}

	/**
	 * ###### METODO PALEATIVO DEVE SER FEITO CONFORME O PADAO DESTA CLASSE ######
	 */
	public long getBinanceServerTime() {

		String ENDPT = "https://api.binance.com/api/v3/time";

		RestTemplate restTemplate = new RestTemplate();

		BinanceServerVO binance = restTemplate.getForObject(ENDPT, BinanceServerVO.class);

		return binance.getServerTime();

	}

	/**
	 * ###### O QUE ESTA COMENTADO E A SINCRONIZACAO DO HORARIO COM O SERVER TIME,
	 * POREM USAR O NTP DO SERVIDOR DE HORARIO DO WINDOWS RESOLVEU
	 */
	private String getTimeStamp() {

		// long timestamp_start = System.currentTimeMillis();
		// long binanceTimestamp = getBinanceServerTime();
		long timestamp_end = System.currentTimeMillis();

		// Sincroniza com tempo do servidor
		// long syncTimestamp = (timestamp_end - timestamp_start) + binanceTimestamp;
		// return "timestamp=" + String.valueOf(syncTimestamp);

		return "timestamp=" + String.valueOf(timestamp_end);
	}

	// concatenate query parameters
	private String joinQueryParameters(HashMap<String, String> parameters) {
		String urlPath = "";
		boolean isFirst = true;

		for (@SuppressWarnings("rawtypes") Map.Entry mapElement : parameters.entrySet()) {
			if (isFirst) {
				isFirst = false;
				urlPath += (String) mapElement.getKey() + "=" + (String) mapElement.getValue();
			} else {
				urlPath += "&" + (String) mapElement.getKey() + "=" + (String) mapElement.getValue();
			}
		}
		return urlPath;
	}

	private String send(URL obj, String httpMethod) throws Exception {
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		if (httpMethod != null) {
			con.setRequestMethod(httpMethod);
		}
		// add API_KEY to header content
		con.setRequestProperty("X-MBX-APIKEY", apiKey);

		int responseCode = con.getResponseCode();
		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			return printResponse(con);
		} else {
			printError(con);
		}
		return null;
	}

	public String sendPublicRequest(HashMap<String, String> parameters, String urlPath) throws Exception {
		String queryPath = joinQueryParameters(parameters);
		URL obj = new URL(baseUrl + urlPath + "?" + queryPath);
		//System.out.println("--> URL API:" + obj.toString());
		return send(obj, null);
	}

	public String sendSignedRequest(HashMap<String, String> parameters, String urlPath, String httpMethod)
			throws Exception {
		String queryPath = "";
		String signature = "";
		if (!parameters.isEmpty()) {
			queryPath += joinQueryParameters(parameters) + "&" + getTimeStamp();
		} else {
			queryPath += getTimeStamp();
		}
		try {
			signature = sign.getSignature(queryPath, apiSecret);
		} catch (Exception e) {
			System.out.println("Please Ensure Your Secret Key Is Set Up Correctly! " + e);
			System.exit(0);
		}
		queryPath += "&signature=" + signature;

		URL obj = new URL(baseUrl + urlPath + "?" + queryPath);

		return send(obj, httpMethod);
	}
}