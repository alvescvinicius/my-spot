package template.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Log {
	
	public Logger logger;
	
	public Log(Class<?> object) {
		super();
		System.out.println("");
		System.out.println("Log: " + object.toString());
		System.out.println("");
		this.logger = LoggerFactory.getLogger(object.getClass());
	}

	public void info(String message) {
		System.out.println("");
		System.out.println(message);
		System.out.println("");
	}
	
	public void debug(String message) {
		System.out.println(message);
	}
	
	public void error(String message) {
		System.err.println("");
		System.err.println(message);
		System.err.println("");
		this.logger.error(message);
	}
	
}
