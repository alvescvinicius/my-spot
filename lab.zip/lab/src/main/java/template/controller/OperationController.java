package template.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import template.model.Balance;
import template.model.Ema;
import template.model.Operation;
import template.params.OperationParams;
import template.service.BalanceService;
import template.service.EmaService;
import template.service.OperationService;

@Component
public class OperationController {

	@Autowired
	private OperationService operationService;
	
	@Autowired
	private EmaService emaService;
	
	@Autowired
	private BalanceService balanceService;

	public void startOperation() throws Exception {

		// --
		// -- 1. Recupera operacao
		// --
		Operation operation = this.operationService.getOperation();
		
		System.out.println("");
		System.out.println(operation);

		// --
		// -- 2. Gera EMA macro
		// --
		Ema emaMacro = this.emaService.getEma(OperationParams.COIN_SYMBOL,
							  				  OperationParams.EMA_MACRO_DESCRIPTION,
							  				  OperationParams.EMA_MACRO_INTERVAL,
							  				  OperationParams.EMA_MACRO_LIMIT,
							  				  OperationParams.EMA_MACRO_SHORT_PERIOD,
							  				  OperationParams.EMA_MACRO_MEDIUM_PERIOD,
							  				  OperationParams.EMA_MACRO_LONG_PERIOD);
		
		System.out.println("");
		System.out.println("-- EMA " + emaMacro.getDescription());
		System.out.println("");
		System.out.println("EMA_LONG   = " + emaMacro.getEmaLong());
		System.out.println("EMA_MEDIUM = " + emaMacro.getEmaMedium());
		System.out.println("EMA_SHORT  = " + emaMacro.getEmaShort());

		// --
		// -- 3. Gera EMA micro
		// --
		Ema emaMicro = this.emaService.getEma(OperationParams.COIN_SYMBOL,
				 			  				  OperationParams.EMA_MICRO_DESCRIPTION,
				 			  				  OperationParams.EMA_MICRO_INTERVAL,
				 			  				  OperationParams.EMA_MICRO_LIMIT,
				 			  				  OperationParams.EMA_MICRO_SHORT_PERIOD,
				 			  				  OperationParams.EMA_MICRO_MEDIUM_PERIOD,
				 			  				  OperationParams.EMA_MICRO_LONG_PERIOD);
		
		System.out.println("");
		System.out.println("-- EMA " + emaMicro.getDescription());
		System.out.println("");
		System.out.println("EMA_LONG   = " + emaMicro.getEmaLong());
		System.out.println("EMA_MEDIUM = " + emaMicro.getEmaMedium());
		System.out.println("EMA_SHORT  = " + emaMicro.getEmaShort());

		// --
		// -- 4. Recupera saldo atual da conta - repensar em colocar em locais que usem apenas se necessario
		// --
		Balance balanceBase = this.balanceService.getBalance(OperationParams.COIN_BASE);
		System.out.println("");
		System.out.println(balanceBase);
		
		Balance balanceTrade = this.balanceService.getBalance(OperationParams.COIN_TRADE);
		System.out.println("");
		System.out.println(balanceTrade);
		
		// --
		// -- 5. Processa compra
		// -- 5.1 Enquanto preço de compra nao foi alcancado, monitorar
		// -- 5.2 Comprar
		processHigh(operation,
					emaMacro,
					emaMicro,
					balanceBase,
					balanceTrade);

		// --
		// -- 6. Processa venda
		// -- 6.1 Enquanto preço de venda nao foi alcancado, monitorar
		// -- 6.2 Vender
		processLow(operation,
				   emaMacro,
				   emaMicro,
				   balanceBase,
				   balanceTrade);

	}
	
	public void processHigh(Operation operation,
							Ema emaMacro,
							Ema emaMicro,
							Balance balanceBase,
							Balance balanceTrade) {
		
		if(this.emaService.emaIsHigh(emaMacro)) {
			
			System.out.println("");
			System.out.println("Ema Macro Is High");
			
			if(this.emaService.emaIsHigh(emaMicro)) {
				
				System.out.println("");
				System.out.println("Ema Micro Is High");
				
			}
			
			if(this.emaService.emaIsLow(emaMicro)) {
				
				System.out.println("");
				System.out.println("Ema Micro Is Low");
				
			}
			
		}
		
	}
	
	public void processLow(Operation operation,
							Ema emaMacro,
							Ema emaMicro,
							Balance balanceBase,
							Balance balanceTrade) {
		
		if(this.emaService.emaIsLow(emaMacro)) {
			
			System.out.println("");
			System.out.println("Ema Macro Is Low");
			
			if(this.emaService.emaIsHigh(emaMicro)) {
				
				System.out.println("");
				System.out.println("Ema Micro Is High");
				
			}
			
			if(this.emaService.emaIsLow(emaMicro)) {
				
				System.out.println("");
				System.out.println("Ema Micro Is Low");
				
			}
			
		}

	}

}
