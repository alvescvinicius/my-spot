package template.dto;

import java.util.List;

import template.model.Balance;

public class Account {

	private int makerCommission;
	private int takerCommission;
	private int buyerCommission;
	private int sellerCommission;
	private CommissionRates commissionRates;
	private boolean canTrade;
	private boolean canWithdraw;
	private boolean canDeposit;
	private boolean brokered;
	private boolean requireSelfTradePrevention;
	private boolean preventSor;
	private long updateTime;
	private String accountType;
	private List<Balance> balances;

	public Account() {

	}

	public int getMakerCommission() {
		return makerCommission;
	}

	public void setMakerCommission(int makerCommission) {
		this.makerCommission = makerCommission;
	}

	public int getTakerCommission() {
		return takerCommission;
	}

	public void setTakerCommission(int takerCommission) {
		this.takerCommission = takerCommission;
	}

	public int getBuyerCommission() {
		return buyerCommission;
	}

	public void setBuyerCommission(int buyerCommission) {
		this.buyerCommission = buyerCommission;
	}

	public int getSellerCommission() {
		return sellerCommission;
	}

	public void setSellerCommission(int sellerCommission) {
		this.sellerCommission = sellerCommission;
	}

	public CommissionRates getCommissionRates() {
		return commissionRates;
	}

	public void setCommissionRates(CommissionRates commissionRates) {
		this.commissionRates = commissionRates;
	}

	public boolean isCanTrade() {
		return canTrade;
	}

	public void setCanTrade(boolean canTrade) {
		this.canTrade = canTrade;
	}

	public boolean isCanWithdraw() {
		return canWithdraw;
	}

	public void setCanWithdraw(boolean canWithdraw) {
		this.canWithdraw = canWithdraw;
	}

	public boolean isCanDeposit() {
		return canDeposit;
	}

	public void setCanDeposit(boolean canDeposit) {
		this.canDeposit = canDeposit;
	}

	public boolean isBrokered() {
		return brokered;
	}

	public void setBrokered(boolean brokered) {
		this.brokered = brokered;
	}

	public boolean isRequireSelfTradePrevention() {
		return requireSelfTradePrevention;
	}

	public void setRequireSelfTradePrevention(boolean requireSelfTradePrevention) {
		this.requireSelfTradePrevention = requireSelfTradePrevention;
	}

	public boolean isPreventSor() {
		return preventSor;
	}

	public void setPreventSor(boolean preventSor) {
		this.preventSor = preventSor;
	}

	public long getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(long updateTime) {
		this.updateTime = updateTime;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public List<Balance> getBalances() {
		return balances;
	}

	public void setBalances(List<Balance> balances) {
		this.balances = balances;
	}

	@Override
	public String toString() {
		return "Account [makerCommission=" + makerCommission + ", takerCommission=" + takerCommission
				+ ", buyerCommission=" + buyerCommission + ", sellerCommission=" + sellerCommission
				+ ", commissionRates=" + commissionRates + ", canTrade=" + canTrade + ", canWithdraw=" + canWithdraw
				+ ", canDeposit=" + canDeposit + ", brokered=" + brokered + ", requireSelfTradePrevention="
				+ requireSelfTradePrevention + ", preventSor=" + preventSor + ", updateTime=" + updateTime
				+ ", accountType=" + accountType + ", balances=" + balances + "]";
	}

}
