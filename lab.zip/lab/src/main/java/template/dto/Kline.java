package template.dto;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.ARRAY)
public class Kline {
	private long openTime;
	private String open;
	private String high;
	private String low;
	private String close;
	private String volume;
	private long closeTime;
	private String quoteAssetVolume;
	private int numberOfTrades;
	private String takerBuyBaseAssetVolume;
	private String takerBuyQuoteAssetVolume;
	private String ignore;

	// Regular constructor
	public Kline(long openTime, String open, String high, String low, String close, String volume, long closeTime,
			String quoteAssetVolume, int numberOfTrades, String takerBuyBaseAssetVolume,
			String takerBuyQuoteAssetVolume, String ignore) {
		this.openTime = openTime;
		this.open = open;
		this.high = high;
		this.low = low;
		this.close = close;
		this.volume = volume;
		this.closeTime = closeTime;
		this.quoteAssetVolume = quoteAssetVolume;
		this.numberOfTrades = numberOfTrades;
		this.takerBuyBaseAssetVolume = takerBuyBaseAssetVolume;
		this.takerBuyQuoteAssetVolume = takerBuyQuoteAssetVolume;
		this.ignore = ignore;
	}

	// JsonCreator with factory method
	@JsonCreator
	public static Kline create(Object[] array) {
		return new Kline(((Number) array[0]).longValue(), // openTime
				(String) array[1], // open
				(String) array[2], // high
				(String) array[3], // low
				(String) array[4], // close
				(String) array[5], // volume
				((Number) array[6]).longValue(), // closeTime
				(String) array[7], // quoteAssetVolume
				((Number) array[8]).intValue(), // numberOfTrades
				(String) array[9], // takerBuyBaseAssetVolume
				(String) array[10], // takerBuyQuoteAssetVolume
				(String) array[11] // ignore
		);
	}

	// Getters...
	public long getOpenTime() {
		return openTime;
	}

	public String getOpen() {
		return open;
	}

	public String getHigh() {
		return high;
	}

	public String getLow() {
		return low;
	}

	public String getClose() {
		return close;
	}

	public String getVolume() {
		return volume;
	}

	public long getCloseTime() {
		return closeTime;
	}

	public String getQuoteAssetVolume() {
		return quoteAssetVolume;
	}

	public int getNumberOfTrades() {
		return numberOfTrades;
	}

	public String getTakerBuyBaseAssetVolume() {
		return takerBuyBaseAssetVolume;
	}

	public String getTakerBuyQuoteAssetVolume() {
		return takerBuyQuoteAssetVolume;
	}

	public String getIgnore() {
		return ignore;
	}

	@Override
	public String toString() {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    return "Kline [openTime=" + dateFormat.format(new Date(openTime)) + 
	           ", open=" + open + 
	           ", high=" + high + 
	           ", low=" + low + 
	           ", close=" + close +
	           ", volume=" + volume + 
	           ", closeTime=" + dateFormat.format(new Date(closeTime)) + 
	           ", quoteAssetVolume=" + quoteAssetVolume +
	           ", numberOfTrades=" + numberOfTrades + 
	           ", takerBuyBaseAssetVolume=" + takerBuyBaseAssetVolume +
	           ", takerBuyQuoteAssetVolume=" + takerBuyQuoteAssetVolume + 
	           ", ignore=" + ignore + "]";
	}

}