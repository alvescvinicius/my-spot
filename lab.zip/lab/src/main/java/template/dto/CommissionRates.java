package template.dto;

public class CommissionRates {

	private String maker;
	private String taker;
	private String buyer;
	private String seller;

	public CommissionRates() {

	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getTaker() {
		return taker;
	}

	public void setTaker(String taker) {
		this.taker = taker;
	}

	public String getBuyer() {
		return buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getSeller() {
		return seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	@Override
	public String toString() {
		return "CommissionRates [maker=" + maker + ", taker=" + taker + ", buyer=" + buyer + ", seller=" + seller + "]";
	}

}
