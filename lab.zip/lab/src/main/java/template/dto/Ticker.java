package template.dto;

import java.io.Serializable;

public class Ticker implements Serializable {

	private static final long serialVersionUID = 1L;

	private long id;
	private String symbol;
	private Double priceChange;
	private Double priceChangePercent;
	private Double weightedAvgPrice;
	private Double prevClosePrice;
	private Double lastPrice;
	private Double lastQty;
	private Double bidPrice;
	private Double bidQty;
	private Double askPrice;
	private Double askQty;
	private Double openPrice;
	private Double highPrice;
	private Double lowPrice;
	private long openTime;
	private long closeTime;
	private long firstId;
	private long lastId;
	private long count;
	private Double variation;

	public Ticker() {

	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public Double getPriceChange() {
		return priceChange;
	}

	public void setPriceChange(Double priceChange) {
		this.priceChange = priceChange;
	}

	public Double getPriceChangePercent() {
		return priceChangePercent;
	}

	public void setPriceChangePercent(Double priceChangePercent) {
		this.priceChangePercent = priceChangePercent;
	}

	public Double getWeightedAvgPrice() {
		return weightedAvgPrice;
	}

	public void setWeightedAvgPrice(Double weightedAvgPrice) {
		this.weightedAvgPrice = weightedAvgPrice;
	}

	public Double getPrevClosePrice() {
		return prevClosePrice;
	}

	public void setPrevClosePrice(Double prevClosePrice) {
		this.prevClosePrice = prevClosePrice;
	}

	public Double getLastPrice() {
		return lastPrice;
	}

	public void setLastPrice(Double lastPrice) {
		this.lastPrice = lastPrice;
	}

	public Double getLastQty() {
		return lastQty;
	}

	public void setLastQty(Double lastQty) {
		this.lastQty = lastQty;
	}

	public Double getBidPrice() {
		return bidPrice;
	}

	public void setBidPrice(Double bidPrice) {
		this.bidPrice = bidPrice;
	}

	public Double getBidQty() {
		return bidQty;
	}

	public void setBidQty(Double bidQty) {
		this.bidQty = bidQty;
	}

	public Double getAskPrice() {
		return askPrice;
	}

	public void setAskPrice(Double askPrice) {
		this.askPrice = askPrice;
	}

	public Double getAskQty() {
		return askQty;
	}

	public void setAskQty(Double askQty) {
		this.askQty = askQty;
	}

	public Double getOpenPrice() {
		return openPrice;
	}

	public void setOpenPrice(Double openPrice) {
		this.openPrice = openPrice;
	}

	public Double getHighPrice() {
		return highPrice;
	}

	public void setHighPrice(Double highPrice) {
		this.highPrice = highPrice;
	}

	public Double getLowPrice() {
		return lowPrice;
	}

	public void setLowPrice(Double lowPrice) {
		this.lowPrice = lowPrice;
	}

	public long getOpenTime() {
		return openTime;
	}

	public void setOpenTime(long openTime) {
		this.openTime = openTime;
	}

	public long getCloseTime() {
		return closeTime;
	}

	public void setCloseTime(long closeTime) {
		this.closeTime = closeTime;
	}

	public long getFirstId() {
		return firstId;
	}

	public void setFirstId(long firstId) {
		this.firstId = firstId;
	}

	public long getLastId() {
		return lastId;
	}

	public void setLastId(long lastId) {
		this.lastId = lastId;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public Double getVariation() {
		return variation;
	}

	public void setVariation(Double variation) {
		this.variation = variation;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((askPrice == null) ? 0 : askPrice.hashCode());
		result = prime * result + ((askQty == null) ? 0 : askQty.hashCode());
		result = prime * result + ((bidPrice == null) ? 0 : bidPrice.hashCode());
		result = prime * result + ((bidQty == null) ? 0 : bidQty.hashCode());
		result = prime * result + (int) (closeTime ^ (closeTime >>> 32));
		result = prime * result + (int) (count ^ (count >>> 32));
		result = prime * result + (int) (firstId ^ (firstId >>> 32));
		result = prime * result + ((highPrice == null) ? 0 : highPrice.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + (int) (lastId ^ (lastId >>> 32));
		result = prime * result + ((lastPrice == null) ? 0 : lastPrice.hashCode());
		result = prime * result + ((lastQty == null) ? 0 : lastQty.hashCode());
		result = prime * result + ((lowPrice == null) ? 0 : lowPrice.hashCode());
		result = prime * result + ((openPrice == null) ? 0 : openPrice.hashCode());
		result = prime * result + (int) (openTime ^ (openTime >>> 32));
		result = prime * result + ((prevClosePrice == null) ? 0 : prevClosePrice.hashCode());
		result = prime * result + ((priceChange == null) ? 0 : priceChange.hashCode());
		result = prime * result + ((priceChangePercent == null) ? 0 : priceChangePercent.hashCode());
		result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
		result = prime * result + ((variation == null) ? 0 : variation.hashCode());
		result = prime * result + ((weightedAvgPrice == null) ? 0 : weightedAvgPrice.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ticker other = (Ticker) obj;
		if (askPrice == null) {
			if (other.askPrice != null)
				return false;
		} else if (!askPrice.equals(other.askPrice))
			return false;
		if (askQty == null) {
			if (other.askQty != null)
				return false;
		} else if (!askQty.equals(other.askQty))
			return false;
		if (bidPrice == null) {
			if (other.bidPrice != null)
				return false;
		} else if (!bidPrice.equals(other.bidPrice))
			return false;
		if (bidQty == null) {
			if (other.bidQty != null)
				return false;
		} else if (!bidQty.equals(other.bidQty))
			return false;
		if (closeTime != other.closeTime)
			return false;
		if (count != other.count)
			return false;
		if (firstId != other.firstId)
			return false;
		if (highPrice == null) {
			if (other.highPrice != null)
				return false;
		} else if (!highPrice.equals(other.highPrice))
			return false;
		if (id != other.id)
			return false;
		if (lastId != other.lastId)
			return false;
		if (lastPrice == null) {
			if (other.lastPrice != null)
				return false;
		} else if (!lastPrice.equals(other.lastPrice))
			return false;
		if (lastQty == null) {
			if (other.lastQty != null)
				return false;
		} else if (!lastQty.equals(other.lastQty))
			return false;
		if (lowPrice == null) {
			if (other.lowPrice != null)
				return false;
		} else if (!lowPrice.equals(other.lowPrice))
			return false;
		if (openPrice == null) {
			if (other.openPrice != null)
				return false;
		} else if (!openPrice.equals(other.openPrice))
			return false;
		if (openTime != other.openTime)
			return false;
		if (prevClosePrice == null) {
			if (other.prevClosePrice != null)
				return false;
		} else if (!prevClosePrice.equals(other.prevClosePrice))
			return false;
		if (priceChange == null) {
			if (other.priceChange != null)
				return false;
		} else if (!priceChange.equals(other.priceChange))
			return false;
		if (priceChangePercent == null) {
			if (other.priceChangePercent != null)
				return false;
		} else if (!priceChangePercent.equals(other.priceChangePercent))
			return false;
		if (symbol == null) {
			if (other.symbol != null)
				return false;
		} else if (!symbol.equals(other.symbol))
			return false;
		if (variation == null) {
			if (other.variation != null)
				return false;
		} else if (!variation.equals(other.variation))
			return false;
		if (weightedAvgPrice == null) {
			if (other.weightedAvgPrice != null)
				return false;
		} else if (!weightedAvgPrice.equals(other.weightedAvgPrice))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Ticker [id=" + id + ", symbol=" + symbol + ", priceChange=" + priceChange + ", priceChangePercent="
				+ priceChangePercent + ", weightedAvgPrice=" + weightedAvgPrice + ", prevClosePrice=" + prevClosePrice
				+ ", lastPrice=" + lastPrice + ", lastQty=" + lastQty + ", bidPrice=" + bidPrice + ", bidQty=" + bidQty
				+ ", askPrice=" + askPrice + ", askQty=" + askQty + ", openPrice=" + openPrice + ", highPrice="
				+ highPrice + ", lowPrice=" + lowPrice + ", openTime=" + openTime + ", closeTime=" + closeTime
				+ ", firstId=" + firstId + ", lastId=" + lastId + ", count=" + count + ", variation=" + variation + "]";
	}

}
