
package template;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication()
@ComponentScan(basePackages = {"template", "template.service", "template.dao", "template.controller"})
@EntityScan(basePackages = {"template.model"})
@EnableJpaRepositories(basePackages = {"template.repository"})
public class Startup {

	public static void main(String[] args) {
		
		SpringApplication.run(Startup.class, args);
		
		/*
		Log logger = new Log(Startup.class);

		try {
			logger.info("Operation Begin");
			SpringApplication.run(Startup.class, args);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		} finally {
			logger.info("Operation End");
			System.exit(0);
		}
		*/

	}

}
