package template.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import template.client.BinanceClient;
import template.dao.EmaDao;
import template.dto.Kline;
import template.model.Ema;
import template.util.EmaCalculator;

@Service
public class EmaService {

	@Autowired
	private EmaDao emaDao;

	@Autowired
	private BinanceClient binanceClient;

	public Ema getLastEmaMacro() {
		Ema ema = this.emaDao.getLastOrNewEmaMacro();
		return null;
	}

	public Ema getEma(String symbol, String description, String interval, int limit, int shortPeriod, int mediumPeriod,
			int longPeriod) throws Exception {

		List<Kline> candles = this.binanceClient.getKlineInformations(symbol, interval, limit);

		List<Double> closes = candles.stream().map(Kline::getClose).map(Double::valueOf).collect(Collectors.toList());

		List<Double> emaShort = EmaCalculator.calculateEMA(closes, shortPeriod);
		List<Double> emaMedium = EmaCalculator.calculateEMA(closes, mediumPeriod);
		List<Double> emaLong = EmaCalculator.calculateEMA(closes, longPeriod);

		Double lastEmaShort = EmaCalculator.getLastValue(emaShort);
		Double lastEmaMedium = EmaCalculator.getLastValue(emaMedium);
		Double lastEmaLong = EmaCalculator.getLastValue(emaLong);

		Ema ema = new Ema();

		ema.setDescription(description);
		ema.setEmaShort(lastEmaShort);
		ema.setEmaMedium(lastEmaMedium);
		ema.setEmaLong(lastEmaLong);
		ema.setDateCriation(new Date());

		return ema;
	}

	public boolean emaIsHigh(Ema ema) {
		if (ema.getEmaShort() >= ema.getEmaMedium() && ema.getEmaShort() >= ema.getEmaLong()) {
			return true;
		}
		return false;
	}
	
	public boolean emaIsLow(Ema ema) {
		if (ema.getEmaShort() < ema.getEmaMedium() && ema.getEmaShort() < ema.getEmaLong()) {
			return true;
		}
		return false;
	}

}
