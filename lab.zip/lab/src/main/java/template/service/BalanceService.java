package template.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import template.client.BinanceClient;
import template.dao.BalanceDao;
import template.model.Balance;

@Service
public class BalanceService {

	@Autowired
	private BalanceDao BalanceDao;

	@Autowired
	private BinanceClient binanceClient;

	public Balance getBalanceByAsset(String asset, List<Balance> balances) {
		for (Balance balance : balances) {
			if (balance.getAsset().equalsIgnoreCase(asset)) {
				return balance;
			}
		}
		return null;
	}

	public Balance getBalance(String asset) throws Exception {
		List<Balance> balances = this.binanceClient.getAccountInformations().getBalances();
		return getBalanceByAsset(asset, balances);
	}

}
